package Automate.QA_Selenium_Automation;

import java.util.Arrays;

public class stringUtils {

	public static boolean isPalindrome(String word) {
        String cleaned = word.replaceAll("[\\W_]", "").toLowerCase();
        return new StringBuilder(cleaned).reverse().toString().equals(cleaned);
    }

    public static boolean areAnagrams(String word1, String word2) {
        char[] a1 = word1.replaceAll("\\s", "").toCharArray();
        char[] a2 = word2.replaceAll("\\s", "").toCharArray();
        Arrays.sort(a1);
        Arrays.sort(a2);
        return Arrays.equals(a1, a2);
    }

}
