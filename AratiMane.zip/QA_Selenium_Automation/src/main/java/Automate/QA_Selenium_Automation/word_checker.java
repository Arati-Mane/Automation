package Automate.QA_Selenium_Automation;

import java.io.IOException;

public class word_checker {

	public static void main(String[] args) throws IOException, InterruptedException {
		String input[] = { "madam", "listen", "silent" };

		check_dictionary dict = new check_dictionary();

		for (int i = 0; i <= input.length - 1; i++) {
			if (!dict.isEnglishWord(input[i])) {
				System.out.println(input[i] + " is not a valid English word.");
				return;
			}
		}

		if (input.length > 0) {
			boolean palindrome = stringUtils.isPalindrome(input[0]);
			System.out.println("Is palindrome: " + palindrome);

			boolean anagram = stringUtils.areAnagrams(input[1], input[2]);
			System.out.println("Are anagrams: " + anagram);
		}
	}
}
