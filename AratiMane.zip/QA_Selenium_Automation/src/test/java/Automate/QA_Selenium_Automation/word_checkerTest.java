package Automate.QA_Selenium_Automation;

import java.io.IOException;

import org.junit.jupiter.api.Test;

public class word_checkerTest {

	@Test
    public void testSingleWordPalindrome() throws IOException, InterruptedException {
        String[] args = {"madam", "listen", "silent"};
        word_checker.main(args);
    }
}
