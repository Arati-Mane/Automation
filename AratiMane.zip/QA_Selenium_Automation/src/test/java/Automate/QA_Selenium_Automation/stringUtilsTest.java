package Automate.QA_Selenium_Automation;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class stringUtilsTest {

	@Test
    public void testPalindrome() {
        assertTrue(stringUtils.isPalindrome("madam"));
        assertFalse(stringUtils.isPalindrome("apple"));
    }

    @Test
    public void testAnagram() {
        assertTrue(stringUtils.areAnagrams("listen", "silent"));
        assertFalse(stringUtils.areAnagrams("hello", "world"));
    }
}
