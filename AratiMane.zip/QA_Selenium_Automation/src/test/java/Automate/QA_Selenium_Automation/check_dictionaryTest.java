package Automate.QA_Selenium_Automation;

import java.io.IOException;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class check_dictionaryTest {

	check_dictionary dict = new check_dictionary();

    @Test
    public void testValidEnglishWord() throws IOException, InterruptedException {
        assertTrue(dict.isEnglishWord("apple"));
    }

    @Test
    public void testInvalidEnglishWord() throws IOException, InterruptedException {
        assertFalse(dict.isEnglishWord("asdfghjkl"));
    }
}
