package Automate.QA_Selenium_Automation;

import java.io.IOException;
import java.net.URI;
import java.net.http.*;

public class check_dictionary {

	private static final String API_URL = "https://api.dictionaryapi.dev/api/v2/entries/en/";

    public boolean isEnglishWord(String word) throws IOException, InterruptedException {
        HttpClient client = HttpClient.newHttpClient();
        HttpRequest request = HttpRequest.newBuilder()
            .uri(URI.create(API_URL + word))
            .GET()
            .build();

        HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
        return response.statusCode() == 200;
    }

}
